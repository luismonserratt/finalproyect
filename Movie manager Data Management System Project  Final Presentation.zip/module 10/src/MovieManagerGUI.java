package com.luismonserratt.moviemanager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * MovieManagerGUI is the graphical interface of the Movie Manager application.
 * It allows users to connect to the database, perform CRUD operations,
 * calculate the average duration, and view all stored movie data.
 * The interface is built using Java Swing.
 */
public class MovieManagerGUI extends JFrame {
    private MovieDAO dao;                 // DAO object to perform database operations
    private JTextArea displayArea;       // Area to display movie records

    /**
     * Constructor initializes the GUI window and sets up all components:
     * - Title bar
     * - Maximized window
     * - Layout with text area and buttons
     * - Button action handlers
     */
    public MovieManagerGUI() {
        dao = new MovieDAO(); // Create instance of MovieDAO to access DB methods

        setTitle("Movie Manager (MySQL)");              // Window title
        setExtendedState(JFrame.MAXIMIZED_BOTH);        // Start window maximized
        setDefaultCloseOperation(EXIT_ON_CLOSE);        // Exit app when window closes
        setLayout(new BorderLayout());                  // Use BorderLayout layout manager

        // Text area setup to display movie data with scroll functionality
        displayArea = new JTextArea(30, 100);           // Set visible rows/columns
        displayArea.setEditable(false);                 // Disable editing
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane, BorderLayout.CENTER);           // Place in the center

        // Create buttons and add them to a grid layout panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 4, 5, 5)); // 2 rows x 4 columns with spacing
        String[] labels = {"Connect", "Display", "Add", "Update", "Delete", "Avg Duration", "Exit"};
        JButton[] buttons = new JButton[labels.length];

        for (int i = 0; i < labels.length; i++) {
            buttons[i] = new JButton(labels[i]);     // Create each button
            buttonPanel.add(buttons[i]);             // Add button to panel
        }

        add(buttonPanel, BorderLayout.SOUTH);        // Add panel to the bottom of window

        // Set up event handlers (actions) for each button
        buttons[0].addActionListener(e -> testConnection());
        buttons[1].addActionListener(e -> displayMovies());
        buttons[2].addActionListener(e -> addMovie());
        buttons[3].addActionListener(e -> updateMovie());
        buttons[4].addActionListener(e -> deleteMovie());
        buttons[5].addActionListener(e -> showAverageDuration());
        buttons[6].addActionListener(e -> System.exit(0)); // Close app
    }

    /**
     * Tests the database connection and shows a confirmation popup.
     */
    private void testConnection() {
        try {
            DatabaseManager.getConnection().close(); // Try connecting and closing DB
            JOptionPane.showMessageDialog(this, "✅ Connection successful!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Connection failed: " + e.getMessage());
        }
    }

    /**
     * Retrieves all movies from the database and displays them in the text area.
     * Also prints to console (optional for debugging).
     */
    private void displayMovies() {
        List<Movie> movies = dao.readAll();             // Get all movies from DB
        StringBuilder sb = new StringBuilder();         // To build text output
        for (Movie m : movies) {
            System.out.println(m);                      // Print in terminal
            sb.append(m).append("\n");                  // Add to text area
        }
        displayArea.setText(sb.toString());             // Show in GUI
        displayArea.setCaretPosition(0);                // Scroll to top
    }

    /**
     * Prompts the user for movie details and adds a new movie to the database.
     * Input validation is basic, errors are handled with try-catch.
     */
    private void addMovie() {
        try {
            // Prompt user for each field
            String title = JOptionPane.showInputDialog("Title:");
            String genre = JOptionPane.showInputDialog("Genre:");
            int year = Integer.parseInt(JOptionPane.showInputDialog("Year:"));
            double rating = Double.parseDouble(JOptionPane.showInputDialog("Rating:"));
            int duration = Integer.parseInt(JOptionPane.showInputDialog("Duration:"));
            boolean watched = Boolean.parseBoolean(JOptionPane.showInputDialog("Watched? (true/false)"));

            // Create movie object and save to database
            Movie movie = new Movie(title, genre, year, rating, duration, watched);
            boolean success = dao.create(movie);

            JOptionPane.showMessageDialog(this, success ? "✅ Movie added." : "❌ Add failed.");
            displayMovies(); // Refresh display
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "⚠️ Invalid input.");
        }
    }

    /**
     * Prompts user for new data for an existing movie and updates it in the database.
     */
    private void updateMovie() {
        try {
            // Prompt for original title and updated fields
            String title = JOptionPane.showInputDialog("Title to update:");
            String genre = JOptionPane.showInputDialog("New genre:");
            int year = Integer.parseInt(JOptionPane.showInputDialog("New year:"));
            double rating = Double.parseDouble(JOptionPane.showInputDialog("New rating:"));
            int duration = Integer.parseInt(JOptionPane.showInputDialog("New duration:"));
            boolean watched = Boolean.parseBoolean(JOptionPane.showInputDialog("Watched? (true/false)"));

            // Create movie with updated values and send to DAO
            Movie movie = new Movie(title, genre, year, rating, duration, watched);
            boolean success = dao.update(movie);

            JOptionPane.showMessageDialog(this, success ? "✅ Movie updated." : "❌ Update failed.");
            displayMovies(); // Refresh list
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "⚠️ Invalid input.");
        }
    }

    /**
     * Prompts user for a movie title and deletes it from the database.
     */
    private void deleteMovie() {
        String title = JOptionPane.showInputDialog("Title to delete:");
        boolean success = dao.delete(title); // Delete by title
        JOptionPane.showMessageDialog(this, success ? "✅ Deleted!" : "❌ Not found.");
        displayMovies(); // Refresh list
    }

    /**
     * Calculates and displays the average duration of all movies in the database.
     */
    private void showAverageDuration() {
        double avg = dao.getAverageDuration(); // Calculate average
        JOptionPane.showMessageDialog(this, "🎬 Average duration: " + String.format("%.2f", avg) + " minutes");
    }

    /**
     * Main method to start the application.
     * Ensures the GUI is launched on the Swing event dispatch thread.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MovieManagerGUI().setVisible(true));
    }
}
